﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestTaskDomKofe.Model
{
  public   class DatabaseHelper
    {
    public  static string ConnectionString = @"Data Source=domkofeserver.database.windows.net;Initial Catalog=DomKofeDB;User ID=Frostiq;Password=Test12345678";

    }
}
